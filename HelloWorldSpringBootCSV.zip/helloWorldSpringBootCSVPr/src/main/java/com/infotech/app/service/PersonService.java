package com.infotech.app.service;

import java.util.List;

import com.infotech.app.model.Person;

public interface PersonService {
	/*
	 * Find the list of persons with a given preferred color from the storage
	 * @param  preferedColor the preferred color id of the person
     * @return the list of persons that prefer the color with id preferedColor
	 */
	public List<Person> findByPreferedColor(Integer preferedColor);
	
	/*
     * @return the list of all persons in the storage
	 */
	public List<Person> findAll();
	
	/*
	 * Create a person in the storage
	 * @param  person the person to be created
     * @return the person if successful
	 */
	public Person create(Person person);
	
	/*
	 * Find out if a person with a given state exists in the storage 
	 * @param person the person to find out the existence the storage 
     * @return true if a person with same state exist
	 */
	public Boolean exist(Person person);
}
