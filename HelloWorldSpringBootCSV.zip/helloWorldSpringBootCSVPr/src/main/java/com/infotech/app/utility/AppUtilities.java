package com.infotech.app.utility;

public class AppUtilities {
	
	/*
	 * The path to the data storage 
	 */
	public static  final String CSVDATA_FILEPATH = "C:\\SpringWorkSpace\\helloWorldSpringBootPr\\src\\main\\resources\\data3.csv";
}
