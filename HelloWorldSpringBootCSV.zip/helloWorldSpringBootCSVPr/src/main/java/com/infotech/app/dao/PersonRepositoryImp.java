package com.infotech.app.dao;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

import com.infotech.app.model.Person;
import com.infotech.app.utility.CsvPersonData;
import com.infotech.app.utility.AppUtilities;

import com.univocity.parsers.common.DataProcessingException;
import com.univocity.parsers.common.ParsingContext;
import com.univocity.parsers.common.RowProcessorErrorHandler;
import com.univocity.parsers.common.processor.BeanListProcessor;
import com.univocity.parsers.csv.CsvParserSettings;
import com.univocity.parsers.csv.CsvRoutines;

@Repository
public class PersonRepositoryImp implements PersonRepository {
	private BiMap<Integer, String> colorMap = HashBiMap.create();
	  
	public PersonRepositoryImp() {
		super();
		   {
			   this.colorMap.put(1,"Blau");
			   this.colorMap.put(2,"Grun");
			   this.colorMap.put(3,"Lila");
			   this.colorMap.put(4,"Rot");
			   this.colorMap.put(5,"ZitronenGelb");
			   this.colorMap.put(6,"Türkis");
			   this.colorMap.put(7,"Weiß");
		   }    
	}
	
	@Override
	public List<Person> findByPreferedColor(Integer preferedColor) {
		File file = new File(AppUtilities.CSVDATA_FILEPATH);
		List<Person> result = new ArrayList<Person>();
		BeanListProcessor<Person> rowProcessor = new BeanListProcessor<Person>(Person.class);
		
		//prepare the settings for the univocity parser
	    CsvParserSettings settings = new CsvParserSettings();
	    settings.setDelimiterDetectionEnabled(true, ',');
	    settings.setReadInputOnSeparateThread(true);
	    settings.setProcessor(rowProcessor);
	    settings.setProcessorErrorHandler(new RowProcessorErrorHandler() {
	        @Override
	        public void handleError(DataProcessingException error, Object[] inputRow, ParsingContext context) {
	            System.out.println("Error processing row: " + Arrays.toString(inputRow));
	            System.out.println("Error details: column '" + error.getColumnName() + "' (index " + error.getColumnIndex() + ") has value '" + inputRow[error.getColumnIndex()] + "'");
	        }
	    });
	    
		CsvRoutines routines = new CsvRoutines(settings);
		Integer index = 1;
		
		//Iterate to get data from the csv file
		for (CsvPersonData csvPersonData : routines.iterate(CsvPersonData.class, file, "UTF-8")) {
			
			//checking if a person has the preferred color
	        if(csvPersonData.getPreferedColor().equalsIgnoreCase(preferedColor.toString())) {
	        	Person person = getPersonFromCsvData(csvPersonData);
	        	person.setId(index);
	        	result.add(person);
	        }
	        index++;
	    }
		return result;
	}
	
	/*
	 * Converting a row from the file storage to a person model
	 * @param  csvPersonData the object representing row from the store file
	 * @return the person model corresponding to csvPersonData
	 */
	private Person getPersonFromCsvData(CsvPersonData csvPersonData) {
		Person person = new Person();
		person.setVorname(csvPersonData.getFirstName());
		person.setNachname(csvPersonData.getName());
	     String [] splittedAddress = csvPersonData.getAddress().split("\\s",2);
	     person.setZipcode(splittedAddress[0]);
	     person.setCity(splittedAddress[1]);
	     person.setColor(this.colorMap.get(Integer.parseInt(csvPersonData.getPreferedColor())));
		return person;	
	}

	@Override
	public Person create(Person person) {
		PrintWriter out;
		try {
			out = new PrintWriter(new FileWriter(AppUtilities.CSVDATA_FILEPATH, true));
			out.append(person.getNachname()+"," + person.getVorname()+"," + person.getZipcode()+" "+person.getCity()+","+ colorMap.inverse().get(person.getColor()));
			out.append(System.getProperty("line.separator"));
			out.flush();
			out.close();
        } catch (IOException ex) {
        	ex.printStackTrace();
        }
		return person;
	}
	
	@Override
	public Boolean exist(Person searchPerson) {
		List<Person> allPersonList = findAll();
		Boolean found = false;
		
		//Iterate to get data from the csv file
		for (Person person : allPersonList) {
			//handle the case where the person with same state is found
	        if (searchPerson.getNachname().trim().equalsIgnoreCase(person.getNachname().trim()) &&
	        		searchPerson.getVorname().trim().equalsIgnoreCase(person.getVorname().trim()) &&
	        		searchPerson.getZipcode().trim().equalsIgnoreCase(person.getZipcode().trim()) &&
	        		searchPerson.getCity().trim().equalsIgnoreCase(person.getCity().trim()) &&
	        		searchPerson.getColor().trim().equalsIgnoreCase(person.getColor().trim())
	        		) return true;
	    }	
		
		return found;
	}
	
	@Override
	public List<Person> findAll() {
		File file = new File(AppUtilities.CSVDATA_FILEPATH);
		List<Person> result = new ArrayList<Person>();
		BeanListProcessor<Person> rowProcessor = new BeanListProcessor<Person>(Person.class);
		
		//prepare the settings for the univocity parser
	    CsvParserSettings settings = new CsvParserSettings();
	    settings.setDelimiterDetectionEnabled(true, ',');
	    settings.setReadInputOnSeparateThread(true);
	    settings.setProcessor(rowProcessor);
	    settings.setProcessorErrorHandler(new RowProcessorErrorHandler() {
	        @Override
	        public void handleError(DataProcessingException error, Object[] inputRow, ParsingContext context) {
	            System.out.println("Error processing row: " + Arrays.toString(inputRow));
	            System.out.println("Error details: column '" + error.getColumnName() + "' (index " + error.getColumnIndex() + ") has value '" + inputRow[error.getColumnIndex()] + "'");
	        }
	    });
	    
		CsvRoutines routines = new CsvRoutines(settings);
		Integer index = 1;
		
		//Iterate to collect all data from the storage file
		for (CsvPersonData csvPersonData : routines.iterate(CsvPersonData.class, file, "UTF-8")) {
			Person person = getPersonFromCsvData(csvPersonData);
	        person.setId(index);
	        result.add(person);
	        index++;
	    }
		return result;
	}
}
