package com.infotech.app.utility;

import com.univocity.parsers.annotations.Parsed;

/*
 * Represent a row in and use to get data from CSV 
 */
public class CsvPersonData {
	@Parsed(index = 0)
	private String name;
	
	@Parsed(index = 1)
	private String firstName;
	 
	@Parsed(index = 2)
	private String address;
	
	@Parsed(index = 3)
	private String preferedColor;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPreferedColor() {
		return preferedColor;
	}
	public void setPreferedColord(String preferedColor) {
		this.preferedColor = preferedColor;
	}
	
	public CsvPersonData(String name, String firstName, String address, String preferedColor) {
		super();
		this.name = name;
		this.firstName = firstName;
		this.address = address;
		this.preferedColor = preferedColor;
	}
	
	public CsvPersonData() {
		super();
	}
	
	@Override
	public String toString() {
		return "Person [name=" + name + ", firstName=" + firstName + ", address=" + address + ", preferedColor="
				+ preferedColor + "]";
	}
}
