package com.infotech.app.dao;
import java.util.List;

import com.infotech.app.model.Person;

public interface PersonRepository {
	/*
	 * Find the list of persons with a given preferred color from the storage
	 * @param  preferedColor the preferred color id
     * @return the list of persons that prefer the color 
	 */
	public List<Person> findByPreferedColor(Integer preferedColor);
	
	/*
     * @return the list of all persons in the storage
	 */
	public List<Person> findAll();
	
	/*
	 * Create a person in the storage
	 * @param  person the person to be created
     * @return the person if successful
	 */
	public Person create(Person person);
	
	/*
	 * Find out if a person with a given state exists in the storage 
	 * @param person the person to find out the existence in the storage 
     * @return true if a person with same state exists in the storage
	 */
	public Boolean exist(Person person);
}
