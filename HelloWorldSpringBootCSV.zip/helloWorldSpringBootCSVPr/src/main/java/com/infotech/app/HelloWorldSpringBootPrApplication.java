package com.infotech.app;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.infotech.app.dao.PersonRepository;
import com.infotech.app.model.Person;
import com.infotech.app.service.PersonService;

@ComponentScan({"com.infotech.app.dao", "com.infotech.app.service", "com.infotech.app.controller" })
@SpringBootApplication
public class HelloWorldSpringBootPrApplication implements CommandLineRunner {
	@Autowired
	PersonRepository personRepository;
	
	@Autowired
	PersonService personService;
	
	public static void main(String[] args)  {
		SpringApplication.run(HelloWorldSpringBootPrApplication.class, args);
    }

	@Override
	public void run(String... args) throws Exception {
		//findByPersonsPreferedColor();
		//findAllPersons();
		//existPerson();
		//createPerson();
	}
	
	/*
	 * Find all persons with a given colorId from storage 
	 */
	public void findByPersonsPreferedColor(){
		List<Person> list = personRepository.findByPreferedColor(1);
		list.forEach(System.out::println);	
	}
	
	/*
	 * Find all persons from storage
	 */
	public void findAllPersons(){
		List<Person> list = personService.findAll();
		list.forEach(System.out::println);	
	}
	
	/*
	 * Find out in a person with the same state exist in the storage
	 */
	 public void existPerson(){
		 Person person = new Person(2, "Markus2","Titus","90408"," Nürnberg", "Blau"); 
		 Boolean result = personService.exist(person);
		 System.out.println("Result: "+result.booleanValue()); 
	 }
	 
	/*
	 * Create a person in the storage 
	 */
	 public void createPerson(){ 
		 Person person1 = new Person(2, "Markus2","Titus","90408", "Nürnberg", "Blau");
		 Person person2 = personRepository.create(person1);
         System.out.println(person2.toString()); }
}

