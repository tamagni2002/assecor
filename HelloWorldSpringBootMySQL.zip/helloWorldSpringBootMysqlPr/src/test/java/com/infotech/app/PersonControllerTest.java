package com.infotech.app;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import static org.hamcrest.CoreMatchers.is;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.infotech.app.controller.PersonController;
import com.infotech.app.model.Person;
import com.infotech.app.service.PersonService;

@RunWith(SpringRunner.class)
@WebMvcTest(PersonController.class)
public class PersonControllerTest {
	
	@Autowired
	private MockMvc mockMvc;
	
	@MockBean
	PersonService personService;
	
	@Test
	public void testGetPersonByPreferedColor() throws Exception {
		
		//creating a mock Person
	    Person mockPerson1 = new Person();
	    mockPerson1.setId(1);
	    mockPerson1.setNachname("Rüdiger");
	    mockPerson1.setVorname("Simon");
	    mockPerson1.setZipcode("90478");
	    mockPerson1.setCity("Münster");
	    mockPerson1.setColor("Lila");
	    List<Person> mockPersonList = Arrays.asList(mockPerson1);
	   
		//Mockito condition
	    Mockito.when(personService.findByPreferedColor(Mockito.anyInt())).thenReturn(mockPersonList);
	    
	    mockMvc.perform(get("/api/persons/color/3")
	    	      .contentType(MediaType.APPLICATION_JSON))
	    	      .andExpect(status().isOk())
	    	      .andExpect(jsonPath("$.length()", is(1)))
	    	      .andExpect(jsonPath("$[0].id", is(mockPerson1.getId())))
	    	      .andExpect(jsonPath("$[0].nachname", is(mockPerson1.getNachname())))
	    	      .andExpect(jsonPath("$[0].vorname", is(mockPerson1.getVorname())))
	    	      .andExpect(jsonPath("$[0].zipcode", is(mockPerson1.getZipcode())))
	    	      .andExpect(jsonPath("$[0].city", is(mockPerson1.getCity())))
	    	      .andExpect(jsonPath("$[0].color", is(mockPerson1.getColor())));
	}
	
	@Test
	public void testGetAllPersons() throws Exception {
		
		//creating a mock Person
	    Person mockPerson1 = new Person();
	    mockPerson1.setId(1);
	    mockPerson1.setNachname("Rüdiger");
	    mockPerson1.setVorname("Simon");
	    mockPerson1.setZipcode("90478");
	    mockPerson1.setCity("Münster");
	    mockPerson1.setColor("Lila");
	    
	    Person mockPerson2 = new Person();
	    mockPerson2.setId(1);
	    mockPerson2.setNachname("Bob");
	    mockPerson2.setVorname("Luther");
	    mockPerson2.setZipcode("90479");
	    mockPerson2.setCity("Münster");
	    mockPerson2.setColor("Blau");
	    
	    List<Person> mockAllPersonList = new ArrayList<Person>();
	    mockAllPersonList.add(mockPerson1);
	    mockAllPersonList.add(mockPerson2);
	   
		//Mockito condition
	    Mockito.when(personService.findAll()).thenReturn(mockAllPersonList);
	    
	    mockMvc.perform(get("/api/persons")
	    	      .contentType(MediaType.APPLICATION_JSON))
	    	      .andExpect(status().isOk())
	    	      .andExpect(jsonPath("$.length()", is(2)))
	    	      .andExpect(jsonPath("$[0].id", is(mockPerson1.getId())))
	    	      .andExpect(jsonPath("$[0].nachname", is(mockPerson1.getNachname())))
	    	      .andExpect(jsonPath("$[0].vorname", is(mockPerson1.getVorname())))
	    	      .andExpect(jsonPath("$[0].zipcode", is(mockPerson1.getZipcode())))
	    	      .andExpect(jsonPath("$[0].city", is(mockPerson1.getCity())))
	    	      .andExpect(jsonPath("$[0].color", is(mockPerson1.getColor())))
	    	      
	    	      .andExpect(jsonPath("$[1].id", is(mockPerson2.getId())))
	    	      .andExpect(jsonPath("$[1].nachname", is(mockPerson2.getNachname())))
	    	      .andExpect(jsonPath("$[1].vorname", is(mockPerson2.getVorname())))
	    	      .andExpect(jsonPath("$[1].zipcode", is(mockPerson2.getZipcode())))
	    	      .andExpect(jsonPath("$[1].city", is(mockPerson2.getCity())))
	    	      .andExpect(jsonPath("$[1].color", is(mockPerson2.getColor())));	    	      	
       }
	
	@Test
	public void testcreatePerson() throws Exception {
		
		//creating a mock Person
	    Person mockPerson1 = new Person();
	    mockPerson1.setNachname("Rüdiger");
	    mockPerson1.setVorname("Simon");
	    mockPerson1.setZipcode("90478");
	    mockPerson1.setCity("Münster");
	    mockPerson1.setColor("Lila");
	      
		//Mockito condition
	    Mockito.when(personService.create(Mockito.any(Person.class))).thenReturn(mockPerson1);
	    
	    mockMvc.perform(post("/api/persons")
	    		  .content(createPersonInJson(
	    				  mockPerson1.getId(),
	    				  mockPerson1.getVorname(), 
	    				  mockPerson1.getNachname(),
	    				  mockPerson1.getZipcode(),
	    				  mockPerson1.getCity(),
	    				  mockPerson1.getColor()))
	    		  .contentType(MediaType.APPLICATION_JSON))
	    		  .andExpect(status().isOk())
	    	      .andExpect(jsonPath("$.length()", is(6))) 
	    	      .andExpect(jsonPath("$.nachname", is(mockPerson1.getNachname())))
			      .andExpect(jsonPath("$.vorname", is(mockPerson1.getVorname())))
			      .andExpect(jsonPath("$.zipcode", is(mockPerson1.getZipcode())))
			      .andExpect(jsonPath("$.city", is(mockPerson1.getCity())))
			      .andExpect(jsonPath("$.color", is(mockPerson1.getColor())));      	    	      	
       }

	private static String createPersonInJson (Integer id, String vorname, String nachname, String zipcode, String city, String color) {
        return "{ \"id\": \"" + id + "\", " +
        		"\"vorname\":\"" + vorname + "\"," +
                "\"nachname\":\"" + nachname + "\"," +
                "\"zipcode\":\"" + zipcode + "\"," +
                "\"city\":\"" + city + "\"," +
                "\"color\":\"" + color + "\"}";
    }
}
