package com.infotech.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infotech.app.dao.PersonRepository;
import com.infotech.app.model.Person;
import com.infotech.app.utility.AppUtilities;

@Service
public class PersonServiceImp implements PersonService{
	@Autowired
	PersonRepository personRepository;

	@Override
	public List<Person> findByPreferedColor(Integer preferedColor) {
		return personRepository.findByColor(AppUtilities.colorMap.get(preferedColor));
	}

	@Override public Person create(Person person) { 
		return personRepository.save(person);
	 }
	 
	  @Override public List<Person> findAll() { 
		  return personRepository.findAll();
	  }

}
