package com.infotech.app.utility;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;

public class AppUtilities {
	
	/*
	 * The path to the data storage 
	 */
	public static  final String CSVDATA_FILEPATH = "C:\\SpringWorkSpace\\helloWorldSpringBootPr\\src\\main\\resources\\data3.csv";
	public static BiMap<Integer, String> colorMap = HashBiMap.create();
	static {
				colorMap.put(1,"Blau");
				colorMap.put(2,"Grun");
				colorMap.put(3,"Lila");
				colorMap.put(4,"Rot");
				colorMap.put(5,"ZitronenGelb");
				colorMap.put(6,"Türkis");
				colorMap.put(7,"Weiß");
			}    	
	}
