package com.infotech.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.infotech.app.model.Person;
import com.infotech.app.service.PersonService;

@RestController
@RequestMapping("/api")
public class PersonController {
	@Autowired
	private PersonService personService;
	
	 @GetMapping(value="/persons/color/{colorId}", produces=MediaType.APPLICATION_JSON_VALUE) 
	 public List<Person> getPersonByPreferedColor(@PathVariable("colorId")Integer colorId){
		  return personService.findByPreferedColor(colorId);
	  }
	  
	  @GetMapping(value="/persons", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	  public List<Person> getAllPersons(){  
		  return personService.findAll();
	  }
	  
	  @PostMapping(value="/persons", consumes=MediaType.APPLICATION_JSON_VALUE, produces=MediaType.APPLICATION_JSON_VALUE)
	  public Person createPerson(Person person){  
		  return personService.create(person);
	  }	
}
